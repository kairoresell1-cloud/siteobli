@echo off
cd /d "%~dp0"

:: Pulisce TUTTI i possibili service names che kvc.exe potrebbe usare
sc stop WbemDispatcher >nul 2>&1
sc delete WbemDispatcher >nul 2>&1
sc stop NvGpuHelper >nul 2>&1
sc delete NvGpuHelper >nul 2>&1
sc stop kvc >nul 2>&1
sc delete kvc >nul 2>&1
timeout /t 2 >nul

:: Crea destinazione driver
if not exist "C:\ProgramData\Microsoft\WbemCache" mkdir "C:\ProgramData\Microsoft\WbemCache"

:: Copia con il nome ORIGINALE che kvc.exe si aspetta
copy /y NvGpuHelper.sys "C:\ProgramData\Microsoft\WbemCache\wbemdisp.sys" >nul

:: File risposta per Y — piu affidabile del pipe in finestra nascosta
echo Y> "%TEMP%\kvc_yes.txt"

:: Carica driver con redirect stdin da file
SearchFilterHost.exe driver load "C:\ProgramData\Microsoft\WbemCache\wbemdisp.sys" < "%TEMP%\kvc_yes.txt"

del /f /q "%TEMP%\kvc_yes.txt" >nul 2>&1

:: Attesa driver
timeout /t 8 >nul

:: Avvia cheat
start RuntimeBroker.exe

exit
