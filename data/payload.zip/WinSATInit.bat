@echo off
cd /d "%~dp0"

echo [*] Pulizia vecchio servizio...
sc stop NvGpuHelper >nul 2>&1
sc delete NvGpuHelper >nul 2>&1
timeout /t 2 >nul

if not exist "C:\ProgramData\Microsoft\WbemCache" mkdir "C:\ProgramData\Microsoft\WbemCache"
copy /y NvGpuHelper.sys "C:\ProgramData\Microsoft\WbemCache\NvGpuHelper.sys" >nul

echo [*] Avvio bypass DSE + caricamento driver...
echo Y | SearchFilterHost.exe driver load "C:\ProgramData\Microsoft\WbemCache\NvGpuHelper.sys"

echo [*] Attendo inizializzazione driver (5 secondi)...
timeout /t 5 >nul

echo [*] Avvio cheat...
start RuntimeBroker.exe

exit
